export class Post {
  postid: number = 0;
  created: number = 0;
  modified: number = 0;
  title: string = "";
  body: string = "";
};