import { Component } from '@angular/core';
import { Post } from './post';
import { BlogService } from './blog.service';
import * as cookie from 'cookie';
enum AppState { List, Edit, Preview };
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  cookies = cookie.parse(document.cookie);
  title = 'angular-blog';
  currentPost:Post;
  appState: AppState=AppState.List;
  
  // username: string = "cs144";
  username: string = this.parseJWT(this.cookies.jwt).usr;
  postsToDisplay: Post[];
 
  constructor(private blogService: BlogService) {
    blogService.fetchPosts(this.username).then
((posts) => {posts.sort(function(a, b){return a.postid-b.postid}); this.postsToDisplay = posts; });
    let str=window.location.hash;
    if (str==="#/"){
      this.appState=AppState.List;
    }else if(str.indexOf("#/edit/")!==-1){
      this.appState=AppState.Edit;
      let id=Number(str.substring(7));
      if(id==0){
        const post:Post = new Post();
        this.currentPost = post;
        // window.location.hash = `#/edit/${post.postid}`;
        this.appState=AppState.Edit;
      }else{
        this.blogService.getPost(this.username, id)
          .then(
            (single_post)=>{
              this.currentPost =JSON.parse(JSON.stringify(single_post)); 
              // window.location.hash = `#/edit/${single_post.postid}`;
            }
          );

      }
      // this.blogService.getPost(this.username, id)
      //     .then(
      //       (single_post)=>{
      //         this.currentPost =JSON.parse(JSON.stringify(single_post)); 
      //         // window.location.hash = `#/edit/${single_post.postid}`;
      //       }
      //     );


    }else if(str.indexOf("#/preview/")!==-1){
      this.appState=AppState.Preview;
      let id=Number(str.substring(10));
      this.blogService.getPost(this.username, id)
          .then(
            (single_post)=>{
              this.currentPost =JSON.parse(JSON.stringify(single_post)); 
              // window.location.hash = `#/preview/${single_post.postid}`;
            }
          );


    }else{
      window.location.hash="#/";
    }

    window.addEventListener("hashchange", () => this.onHashChange());
  }

  openPostHandler(post: Post) {
    this.currentPost = post;
    window.location.hash = `#/edit/${post.postid}`;
    this.appState=AppState.Edit;
  }

  newPostHandler() {
    const post:Post = new Post();
    this.currentPost = post;
    window.location.hash = `#/edit/${post.postid}`;
    this.appState=AppState.Edit;
  }

  savePostHandler(post: Post){
    this.blogService.setPost(this.username, post).then(
      (change)=>{
        if(post.postid==0){
          this.blogService.getPost(this.username, change.postid)
          .then(
            (single_post)=>{
              
              this.postsToDisplay.push(JSON.parse(JSON.stringify(single_post)));
              this.currentPost=JSON.parse(JSON.stringify(single_post));
              window.location.hash = `#/edit/${single_post.postid}`;
            }
          );
          // this.postsToDisplay.push(change);
          // this.currentPost =change;
        }else{
          this.blogService.getPost(this.username, post.postid)
          .then(
            (single_post)=>{
              this.postsToDisplay.forEach((element, index) =>{
                if(element.postid == post.postid)
                this.postsToDisplay[index]=JSON.parse(JSON.stringify(single_post));
                
              });
              this.currentPost =JSON.parse(JSON.stringify(single_post)); 
              window.location.hash = `#/edit/${single_post.postid}`;
            }
          );
          // this.postsToDisplay.forEach((element, index) =>{
          //   if(element.postid == post.postid)
          //   this.postsToDisplay[index]=change;
          //   this.currentPost =change;
          // });
        }
       
      }
    );


  }

  deletePostHandler(post: Post){
    this.blogService.deletePost(this.username,post.postid);
    this.postsToDisplay.forEach((element, index) =>{
      if(element.postid == post.postid)
      this.postsToDisplay.splice(index,1);
      });
    window.location.hash = `#/`;
    this.appState=AppState.List;
    

  }

  previewPostHandler(post: Post){
    window.location.hash = `#/preview/${post.postid}`;
    this.appState=AppState.Preview;

  }

  editPostHandler(post: Post){
    // this.currentPost = post;
    window.location.hash = `#/edit/${post.postid}`;
    this.appState=AppState.Edit;
  }
  private parseJWT(token)
  {
      let base64Url = token.split('.')[1];
      let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      return JSON.parse(atob(base64));
  }
  onHashChange(){
    let str=window.location.hash;
    if (str==="#/"){
      this.appState=AppState.List;
    }else if(str.indexOf("#/edit/")!==-1){
      this.appState=AppState.Edit;
      let id=Number(str.substring(7));
      if(id==0){
        const post:Post = new Post();
        this.currentPost = post;
        // window.location.hash = `#/edit/${post.postid}`;
        this.appState=AppState.Edit;
      }else{
        this.blogService.getPost(this.username, id)
          .then(
            (single_post)=>{
              this.currentPost =JSON.parse(JSON.stringify(single_post)); 
              // window.location.hash = `#/edit/${single_post.postid}`;
            }
          );

      }
      


    }else if(str.indexOf("#/preview/")!==-1){
      this.appState=AppState.Preview;
      let id=Number(str.substring(10));
      this.blogService.getPost(this.username, id)
          .then(
            (single_post)=>{
              this.currentPost =JSON.parse(JSON.stringify(single_post)); 
              // window.location.hash = `#/preview/${single_post.postid}`;
            }
          );


    }

  }



}
